import unittest
import imageSpider
class testImageSpider(unittest.TestCase):

	def setUp(self):
		pass

	def testGetHTMLText(self):
		newSpiderVictim = imageSpider.imageSpider()
		newSpiderVictim.getHTMLText("http://www.imgur.com")

	def testSpiderImages(self):
		newSpiderVictim = imageSpider.imageSpider()
		newSpiderVictim.spiderImages("http://www.imgur.com")

	def tearDown(self):
		pass
	
if __name__ == '__main__':
	unittest.main()
