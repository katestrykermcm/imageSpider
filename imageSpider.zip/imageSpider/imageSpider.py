__author__ = "RJ Silberman"
__version__ = 1.0
import urllib2
from os.path import basename
from urlparse import urlsplit
from bs4 import BeautifulSoup
class imageSpider:
	
	def __init__(self):
		'''Initializes a new imageSpider object.'''
		self.htmlText = ""
		self.imageList = []
	
	def getHTMLText(self, addressToOpen):
		'''Method that provides the raw HTML data for catchImages using urllib2 library.'''
		urlFile = urllib2.urlopen(addressToOpen)
		self.htmlText = urlFile.read()
		
	def spiderImages(self, addressToCrawl):
		'''Method that takes all of the items with an img tag and downloads the images to a new file.'''
		self.getHTMLText(addressToCrawl)
		soup = BeautifulSoup(self.htmlText)
		for link in soup.find_all('img'):
			foundImages = link.get('src')
			if foundImages[0:5] == "http:":
				self.imageList.append(foundImages)		
		for foundItems in self.imageList:
			if foundItems != None:
				imageUrl = foundItems
				imageData = urllib2.urlopen(imageUrl).read()
				fileName = basename(urlsplit(imageUrl)[2])
				spiderOutput = open(fileName, 'w')
				spiderOutput.write(imageData)
				spiderOutput.close()
			

